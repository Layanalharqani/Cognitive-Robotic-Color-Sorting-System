from controller import Robot, Camera, DistanceSensor
import numpy as np

robot = Robot()
TIME_STEP = 32
speed = 2.0

gripper_fingers = [robot.getDevice("finger_1_joint_1"), 
                   robot.getDevice("finger_2_joint_1"), 
                   robot.getDevice("finger_middle_joint_1")]

arm_motors = [robot.getDevice("shoulder_pan_joint"),
              robot.getDevice("shoulder_lift_joint"), 
              robot.getDevice("elbow_joint"), 
              robot.getDevice("wrist_1_joint"), 
              robot.getDevice("wrist_2_joint")]

for motor in arm_motors:
    motor.setVelocity(speed)

camera = robot.getDevice("camera_1")
camera.enable(TIME_STEP)

distance_sensor = robot.getDevice("distance_sensor_1")
distance_sensor.enable(TIME_STEP)

targets = {
    'red':   [-1.57, -1.87, -2.13, -2.36, -1.50],
    'green': [-0.45, -1.50, -1.80, -1.50, -1.00], 
    'blue':  [-1.95, -0.25, 0.12, 0, 3.14]
}

def get_color(cam):
    img = cam.getImage()
    if not img: return 'unknown'
    w, h = cam.getWidth(), cam.getHeight()
    r = cam.imageGetRed(img, w, w//2, h//2)
    g = cam.imageGetGreen(img, w, w//2, h//2)
    b = cam.imageGetBlue(img, w, w//2, h//2)
    
    if r > g and r > b: return 'red'
    if g > r and g > b: return 'green'
    if b > r and b > g: return 'blue'
    return 'unknown'

state = "WAIT_FOR_OBJECT"
counter = 0
current_color = 'unknown'

DIST_THRESHOLD = 110          
WAIT_TO_REACH_CENTER = 22       
SAFE_OPEN_POS = 0.05          
# -----------------------------

while robot.step(TIME_STEP) != -1:
    
    dist = distance_sensor.getValue()
    
    if counter > 0:
        counter -= 1
        continue

    if state == "WAIT_FOR_OBJECT":
        for f in gripper_fingers: f.setPosition(SAFE_OPEN_POS)
        for m in arm_motors: m.setPosition(0)
        
        if dist < DIST_THRESHOLD:
            current_color = get_color(camera)
            if current_color != 'unknown':
                print(f"Object detected: {current_color}. Timing its arrival...")
                state = "DELAY_FOR_CENTER"
                counter = WAIT_TO_REACH_CENTER

    elif state == "DELAY_FOR_CENTER":
        print(f"Centered! Grabbing the {current_color} cube.")
        for f in gripper_fingers: f.setPosition(0.6)
        state = "LIFT_BEFORE_MOVE"  
        counter = 15

    elif state == "LIFT_BEFORE_MOVE":
        arm_motors[1].setPosition(-1.0) 
        state = "MOVE_TO_TARGET"
        counter = 10

    elif state == "MOVE_TO_TARGET":
        pos = targets.get(current_color, [0,0,0,0,0])
        for i in range(5):
            arm_motors[i].setPosition(pos[i])
        state = "RELEASE"
        counter = 80 

    elif state == "RELEASE":
        print(f"Releasing {current_color} in its box.")
        for f in gripper_fingers: f.setPosition(SAFE_OPEN_POS)
        state = "RESET_ARM"
        counter = 40

    elif state == "RESET_ARM":
        for m in arm_motors: m.setPosition(0)
        state = "WAIT_FOR_OBJECT"
        counter = 60  